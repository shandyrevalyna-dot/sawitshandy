<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateKebunTable extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id' => [
                'type'           => 'INT',
                'constraint'     => 11,
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'kode_kebun' => [
                'type'       => 'VARCHAR',
                'constraint' => 20,
                'unique'     => true,
            ],
            'nama_kebun' => [
                'type'       => 'VARCHAR',
                'constraint' => 100,
            ],
            'lokasi' => [
                'type'       => 'VARCHAR',
                'constraint' => 150,
            ],
            'luas_lahan' => [
                'type'       => 'DECIMAL',
                'constraint' => '10,2',
                'comment'    => 'dalam hektar',
            ],
            'tahun_tanam' => [
                'type'       => 'YEAR',
            ],
            'keterangan' => [
                'type' => 'TEXT',
                'null' => true,
            ],
            'created_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'updated_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->createTable('kebun');
    }

    public function down()
    {
        $this->forge->dropTable('kebun');
    }
}
