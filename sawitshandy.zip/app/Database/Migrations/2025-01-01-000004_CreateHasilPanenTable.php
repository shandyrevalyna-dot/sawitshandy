<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateHasilPanenTable extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id' => [
                'type'           => 'INT',
                'constraint'     => 11,
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'kebun_id' => [
                'type'       => 'INT',
                'constraint' => 11,
                'unsigned'   => true,
            ],
            'blok_id' => [
                'type'       => 'INT',
                'constraint' => 11,
                'unsigned'   => true,
            ],
            'jumlah_panen' => [
                'type'       => 'DECIMAL',
                'constraint' => '10,2',
                'comment'    => 'dalam kg',
            ],
            'tanggal_panen' => [
                'type' => 'DATE',
            ],
            'created_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'updated_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addForeignKey('kebun_id', 'kebun', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('blok_id', 'blok_kebun', 'id', 'CASCADE', 'CASCADE');
        $this->forge->createTable('hasil_panen');
    }

    public function down()
    {
        $this->forge->dropTable('hasil_panen');
    }
}
