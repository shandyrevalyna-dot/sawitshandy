<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateBlokKebunTable extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id' => [
                'type'           => 'INT',
                'constraint'     => 11,
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'kebun_id' => [
                'type'       => 'INT',
                'constraint' => 11,
                'unsigned'   => true,
            ],
            'kode_blok' => [
                'type'       => 'VARCHAR',
                'constraint' => 20,
                'unique'     => true,
            ],
            'nama_blok' => [
                'type'       => 'VARCHAR',
                'constraint' => 100,
            ],
            'luas_blok' => [
                'type'       => 'DECIMAL',
                'constraint' => '10,2',
            ],
            'jumlah_pohon' => [
                'type'       => 'INT',
                'constraint' => 11,
            ],
            'status_blok' => [
                'type'       => 'ENUM',
                'constraint' => ['Aktif', 'Tidak Aktif', 'Replanting'],
                'default'    => 'Aktif',
            ],
            'created_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'updated_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addForeignKey('kebun_id', 'kebun', 'id', 'CASCADE', 'CASCADE');
        $this->forge->createTable('blok_kebun');
    }

    public function down()
    {
        $this->forge->dropTable('blok_kebun');
    }
}
