<?php

use CodeIgniter\Router\RouteCollection;

/** @var RouteCollection $routes */

// ==== Halaman Login (tidak butuh auth) ====
$routes->get('/', 'Auth::index');
$routes->get('/login', 'Auth::index');
$routes->post('/login/proses', 'Auth::proses');
$routes->get('/logout', 'Auth::logout');

// ==== Halaman yang butuh login (dibungkus filter 'auth') ====
$routes->group('', ['filter' => 'auth'], function ($routes) {

    $routes->get('dashboard', 'Dashboard::index');

    // Data Kebun
    $routes->get('kebun', 'Kebun::index');
    $routes->get('kebun/tambah', 'Kebun::tambah');
    $routes->post('kebun/simpan', 'Kebun::simpan');
    $routes->get('kebun/edit/(:num)', 'Kebun::edit/$1');
    $routes->post('kebun/update/(:num)', 'Kebun::update/$1');
    $routes->get('kebun/hapus/(:num)', 'Kebun::hapus/$1');

    // Data Blok Kebun
    $routes->get('blok', 'BlokKebun::index');
    $routes->get('blok/tambah', 'BlokKebun::tambah');
    $routes->post('blok/simpan', 'BlokKebun::simpan');
    $routes->get('blok/edit/(:num)', 'BlokKebun::edit/$1');
    $routes->post('blok/update/(:num)', 'BlokKebun::update/$1');
    $routes->get('blok/hapus/(:num)', 'BlokKebun::hapus/$1');

    // Data Hasil Panen
    $routes->get('panen', 'HasilPanen::index');
    $routes->get('panen/tambah', 'HasilPanen::tambah');
    $routes->post('panen/simpan', 'HasilPanen::simpan');
    $routes->get('panen/edit/(:num)', 'HasilPanen::edit/$1');
    $routes->post('panen/update/(:num)', 'HasilPanen::update/$1');
    $routes->get('panen/hapus/(:num)', 'HasilPanen::hapus/$1');
});
