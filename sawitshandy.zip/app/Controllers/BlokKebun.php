<?php

namespace App\Controllers;

use App\Models\BlokKebunModel;
use App\Models\KebunModel;

class BlokKebun extends BaseController
{
    protected BlokKebunModel $blokModel;
    protected KebunModel $kebunModel;

    public function __construct()
    {
        $this->blokModel  = new BlokKebunModel();
        $this->kebunModel = new KebunModel();
    }

    public function index()
    {
        $data = [
            'title' => 'Data Blok Kebun',
            'blok'  => $this->blokModel->getBlokWithKebun(),
        ];
        return view('blok/index', $data);
    }

    public function tambah()
    {
        $data = [
            'title'      => 'Tambah Blok Kebun',
            'listKebun'  => $this->kebunModel->orderBy('nama_kebun', 'ASC')->findAll(),
        ];
        return view('blok/tambah', $data);
    }

    public function simpan()
    {
        if (! $this->validate($this->blokModel->validationRules)) {
            return redirect()->to('/blok/tambah')->withInput()->with('errors', $this->validator->getErrors());
        }

        $this->blokModel->save([
            'kebun_id'     => $this->request->getPost('kebun_id'),
            'kode_blok'    => $this->request->getPost('kode_blok'),
            'nama_blok'    => $this->request->getPost('nama_blok'),
            'luas_blok'    => $this->request->getPost('luas_blok'),
            'jumlah_pohon' => $this->request->getPost('jumlah_pohon'),
            'status_blok'  => $this->request->getPost('status_blok'),
        ]);

        session()->setFlashdata('sukses', 'Data blok kebun berhasil ditambahkan.');
        return redirect()->to('/blok');
    }

    public function edit($id)
    {
        $data = [
            'title'     => 'Edit Blok Kebun',
            'blok'      => $this->blokModel->find($id),
            'listKebun' => $this->kebunModel->orderBy('nama_kebun', 'ASC')->findAll(),
        ];

        if (! $data['blok']) {
            return redirect()->to('/blok')->with('error', 'Data tidak ditemukan.');
        }

        return view('blok/edit', $data);
    }

    public function update($id)
    {
        $rules = $this->blokModel->validationRules;
        $rules['kode_blok'] = "required|is_unique[blok_kebun.kode_blok,id,{$id}]";

        if (! $this->validate($rules)) {
            return redirect()->to('/blok/edit/' . $id)->withInput()->with('errors', $this->validator->getErrors());
        }

        $this->blokModel->update($id, [
            'kebun_id'     => $this->request->getPost('kebun_id'),
            'kode_blok'    => $this->request->getPost('kode_blok'),
            'nama_blok'    => $this->request->getPost('nama_blok'),
            'luas_blok'    => $this->request->getPost('luas_blok'),
            'jumlah_pohon' => $this->request->getPost('jumlah_pohon'),
            'status_blok'  => $this->request->getPost('status_blok'),
        ]);

        session()->setFlashdata('sukses', 'Data blok kebun berhasil diperbarui.');
        return redirect()->to('/blok');
    }

    public function hapus($id)
    {
        $this->blokModel->delete($id);
        session()->setFlashdata('sukses', 'Data blok kebun berhasil dihapus.');
        return redirect()->to('/blok');
    }
}
