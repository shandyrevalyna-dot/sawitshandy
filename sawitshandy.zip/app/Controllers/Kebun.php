<?php

namespace App\Controllers;

use App\Models\KebunModel;

class Kebun extends BaseController
{
    protected KebunModel $kebunModel;

    public function __construct()
    {
        $this->kebunModel = new KebunModel();
    }

    public function index()
    {
        $data = [
            'title' => 'Data Kebun',
            'kebun' => $this->kebunModel->orderBy('id', 'DESC')->findAll(),
        ];
        return view('kebun/index', $data);
    }

    public function tambah()
    {
        return view('kebun/tambah', ['title' => 'Tambah Data Kebun']);
    }

    public function simpan()
    {
        if (! $this->validate($this->kebunModel->validationRules)) {
            return redirect()->to('/kebun/tambah')->withInput()->with('errors', $this->validator->getErrors());
        }

        $this->kebunModel->save([
            'kode_kebun'  => $this->request->getPost('kode_kebun'),
            'nama_kebun'  => $this->request->getPost('nama_kebun'),
            'lokasi'      => $this->request->getPost('lokasi'),
            'luas_lahan'  => $this->request->getPost('luas_lahan'),
            'tahun_tanam' => $this->request->getPost('tahun_tanam'),
            'keterangan'  => $this->request->getPost('keterangan'),
        ]);

        session()->setFlashdata('sukses', 'Data kebun berhasil ditambahkan.');
        return redirect()->to('/kebun');
    }

    public function edit($id)
    {
        $data = [
            'title' => 'Edit Data Kebun',
            'kebun' => $this->kebunModel->find($id),
        ];

        if (! $data['kebun']) {
            return redirect()->to('/kebun')->with('error', 'Data tidak ditemukan.');
        }

        return view('kebun/edit', $data);
    }

    public function update($id)
    {
        $rules = $this->kebunModel->validationRules;
        $rules['kode_kebun'] = "required|is_unique[kebun.kode_kebun,id,{$id}]";

        if (! $this->validate($rules)) {
            return redirect()->to('/kebun/edit/' . $id)->withInput()->with('errors', $this->validator->getErrors());
        }

        $this->kebunModel->update($id, [
            'kode_kebun'  => $this->request->getPost('kode_kebun'),
            'nama_kebun'  => $this->request->getPost('nama_kebun'),
            'lokasi'      => $this->request->getPost('lokasi'),
            'luas_lahan'  => $this->request->getPost('luas_lahan'),
            'tahun_tanam' => $this->request->getPost('tahun_tanam'),
            'keterangan'  => $this->request->getPost('keterangan'),
        ]);

        session()->setFlashdata('sukses', 'Data kebun berhasil diperbarui.');
        return redirect()->to('/kebun');
    }

    public function hapus($id)
    {
        $this->kebunModel->delete($id);
        session()->setFlashdata('sukses', 'Data kebun berhasil dihapus.');
        return redirect()->to('/kebun');
    }
}
