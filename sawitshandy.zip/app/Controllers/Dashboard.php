<?php

namespace App\Controllers;

use App\Models\KebunModel;
use App\Models\HasilPanenModel;

class Dashboard extends BaseController
{
    public function index()
    {
        $kebunModel  = new KebunModel();
        $panenModel  = new HasilPanenModel();

        $rekap = $panenModel->rekapPanenPerBulan();

        $labelBulan = [];
        $dataPanen  = [];
        foreach ($rekap as $row) {
            $labelBulan[] = date('M Y', strtotime($row['bulan'] . '-01'));
            $dataPanen[]  = (float) $row['total'];
        }

        $data = [
            'title'          => 'Dashboard',
            'totalKebun'     => $kebunModel->countAllResults(),
            'totalLuasLahan' => $kebunModel->totalLuasLahan(),
            'totalProduksi'  => $panenModel->totalProduksiBulanIni(),
            'labelBulan'     => json_encode($labelBulan),
            'dataPanen'      => json_encode($dataPanen),
        ];

        return view('dashboard/index', $data);
    }
}
