<?php

namespace App\Controllers;

use App\Models\HasilPanenModel;
use App\Models\KebunModel;
use App\Models\BlokKebunModel;

class HasilPanen extends BaseController
{
    protected HasilPanenModel $panenModel;
    protected KebunModel $kebunModel;
    protected BlokKebunModel $blokModel;

    public function __construct()
    {
        $this->panenModel = new HasilPanenModel();
        $this->kebunModel = new KebunModel();
        $this->blokModel  = new BlokKebunModel();
    }

    public function index()
    {
        $data = [
            'title' => 'Data Hasil Panen',
            'panen' => $this->panenModel->getPanenWithRelasi(),
        ];
        return view('panen/index', $data);
    }

    public function tambah()
    {
        $data = [
            'title'     => 'Tambah Hasil Panen',
            'listKebun' => $this->kebunModel->orderBy('nama_kebun', 'ASC')->findAll(),
            'listBlok'  => $this->blokModel->orderBy('nama_blok', 'ASC')->findAll(),
        ];
        return view('panen/tambah', $data);
    }

    public function simpan()
    {
        if (! $this->validate($this->panenModel->validationRules)) {
            return redirect()->to('/panen/tambah')->withInput()->with('errors', $this->validator->getErrors());
        }

        $this->panenModel->save([
            'kebun_id'      => $this->request->getPost('kebun_id'),
            'blok_id'       => $this->request->getPost('blok_id'),
            'jumlah_panen'  => $this->request->getPost('jumlah_panen'),
            'tanggal_panen' => $this->request->getPost('tanggal_panen'),
        ]);

        session()->setFlashdata('sukses', 'Data hasil panen berhasil ditambahkan.');
        return redirect()->to('/panen');
    }

    public function edit($id)
    {
        $data = [
            'title'     => 'Edit Hasil Panen',
            'panen'     => $this->panenModel->find($id),
            'listKebun' => $this->kebunModel->orderBy('nama_kebun', 'ASC')->findAll(),
            'listBlok'  => $this->blokModel->orderBy('nama_blok', 'ASC')->findAll(),
        ];

        if (! $data['panen']) {
            return redirect()->to('/panen')->with('error', 'Data tidak ditemukan.');
        }

        return view('panen/edit', $data);
    }

    public function update($id)
    {
        if (! $this->validate($this->panenModel->validationRules)) {
            return redirect()->to('/panen/edit/' . $id)->withInput()->with('errors', $this->validator->getErrors());
        }

        $this->panenModel->update($id, [
            'kebun_id'      => $this->request->getPost('kebun_id'),
            'blok_id'       => $this->request->getPost('blok_id'),
            'jumlah_panen'  => $this->request->getPost('jumlah_panen'),
            'tanggal_panen' => $this->request->getPost('tanggal_panen'),
        ]);

        session()->setFlashdata('sukses', 'Data hasil panen berhasil diperbarui.');
        return redirect()->to('/panen');
    }

    public function hapus($id)
    {
        $this->panenModel->delete($id);
        session()->setFlashdata('sukses', 'Data hasil panen berhasil dihapus.');
        return redirect()->to('/panen');
    }
}
