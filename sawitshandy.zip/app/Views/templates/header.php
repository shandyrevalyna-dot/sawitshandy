<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SawitShandy | <?= esc($title ?? 'Dashboard') ?></title>

    <!-- Bootstrap 5 CDN (tanpa file CSS terpisah, style tambahan ditulis inline di bawah) -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">

    <style>
        :root {
            --hijau-tua: #14532d;
            --hijau: #16a34a;
            --hijau-muda: #86efac;
            --putih: #ffffff;
            --abu: #f4f6f5;
        }

        body {
            background: linear-gradient(160deg, #f4faf6 0%, #e7f5ec 40%, #ffffff 100%);
            font-family: 'Segoe UI', Tahoma, sans-serif;
            min-height: 100vh;
        }

        /* ===== Sidebar ===== */
        .sidebar {
            min-height: 100vh;
            background: linear-gradient(180deg, var(--hijau-tua) 0%, var(--hijau) 100%);
            color: var(--putih);
            width: 240px;
            position: fixed;
            top: 0; left: 0; bottom: 0;
        }
        .sidebar .brand {
            padding: 22px 18px;
            font-size: 22px;
            font-weight: 700;
            border-bottom: 1px solid rgba(255,255,255,0.15);
        }
        .sidebar .brand span { color: var(--hijau-muda); }
        .sidebar a {
            color: #e7f5ec;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 12px 20px;
            font-size: 15px;
            border-left: 4px solid transparent;
            transition: 0.2s;
        }
        .sidebar a:hover, .sidebar a.active {
            background: rgba(255,255,255,0.12);
            border-left: 4px solid var(--hijau-muda);
            color: var(--putih);
        }
        .content {
            margin-left: 240px;
            padding: 24px 30px;
        }
        .topbar {
            background: var(--putih);
            border-radius: 14px;
            padding: 14px 20px;
            box-shadow: 0 2px 10px rgba(20,83,45,0.08);
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 22px;
        }
        .card-stat {
            border: none;
            border-radius: 16px;
            color: var(--putih);
            box-shadow: 0 4px 14px rgba(20,83,45,0.15);
        }
        .card-stat.g1 { background: linear-gradient(135deg, #16a34a, #14532d); }
        .card-stat.g2 { background: linear-gradient(135deg, #22c55e, #15803d); }
        .card-stat.g3 { background: linear-gradient(135deg, #4ade80, #16a34a); }
        .card-white {
            background: var(--putih);
            border: 1px solid #e7f5ec;
            border-radius: 16px;
            box-shadow: 0 2px 10px rgba(20,83,45,0.06);
        }
        .btn-hijau {
            background: linear-gradient(135deg, #16a34a, #14532d);
            color: #fff; border: none;
        }
        .btn-hijau:hover { background: linear-gradient(135deg, #15803d, #0f3d20); color: #fff; }
        table thead { background: var(--abu); }
        .badge-aktif { background: #16a34a; }
        .badge-nonaktif { background: #6b7280; }
        .badge-replanting { background: #f59e0b; }
    </style>
</head>
<body>

<?php if (session()->get('isLoggedIn')): ?>
<div class="sidebar">
    <div class="brand">🌴 Sawit<span>Shandy</span></div>
    <a href="<?= base_url('dashboard') ?>" class="<?= uri_string() == 'dashboard' ? 'active' : '' ?>">
        <i class="bi bi-speedometer2"></i> Dashboard
    </a>
    <a href="<?= base_url('kebun') ?>" class="<?= str_contains(uri_string(), 'kebun') ? 'active' : '' ?>">
        <i class="bi bi-tree"></i> Data Kebun
    </a>
    <a href="<?= base_url('blok') ?>" class="<?= str_contains(uri_string(), 'blok') ? 'active' : '' ?>">
        <i class="bi bi-grid-3x3-gap"></i> Data Blok Kebun
    </a>
    <a href="<?= base_url('panen') ?>" class="<?= str_contains(uri_string(), 'panen') ? 'active' : '' ?>">
        <i class="bi bi-basket"></i> Hasil Panen
    </a>
    <a href="<?= base_url('logout') ?>">
        <i class="bi bi-box-arrow-right"></i> Logout
    </a>
</div>
<div class="content">
    <div class="topbar">
        <h5 class="m-0 fw-bold" style="color:#14532d"><?= esc($title ?? '') ?></h5>
        <div class="text-end">
            <div class="fw-semibold" style="color:#14532d"><?= esc(session()->get('nama')) ?></div>
            <small class="text-muted">@<?= esc(session()->get('username')) ?></small>
        </div>
    </div>

    <?php if (session()->getFlashdata('sukses')): ?>
        <div class="alert alert-success"><?= esc(session()->getFlashdata('sukses')) ?></div>
    <?php endif; ?>
    <?php if (session()->getFlashdata('error')): ?>
        <div class="alert alert-danger"><?= esc(session()->getFlashdata('error')) ?></div>
    <?php endif; ?>
<?php endif; ?>
