<?= $this->include('templates/header') ?>

<div class="card card-white p-4" style="max-width:640px">
    <h6 class="fw-bold mb-3" style="color:#14532d">Tambah Blok Kebun</h6>

    <?php if (session('errors')): ?>
        <div class="alert alert-danger">
            <ul class="m-0">
                <?php foreach (session('errors') as $err): ?>
                    <li><?= esc($err) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?= base_url('blok/simpan') ?>" method="post">
        <?= csrf_field() ?>
        <div class="mb-3">
            <label class="form-label">Kebun</label>
            <select name="kebun_id" class="form-select" required>
                <option value="">-- Pilih Kebun --</option>
                <?php foreach ($listKebun as $k): ?>
                    <option value="<?= $k['id'] ?>" <?= old('kebun_id') == $k['id'] ? 'selected' : '' ?>>
                        <?= esc($k['nama_kebun']) ?> (<?= esc($k['kode_kebun']) ?>)
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="mb-3">
            <label class="form-label">Kode Blok</label>
            <input type="text" name="kode_blok" class="form-control" value="<?= old('kode_blok') ?>" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Nama Blok</label>
            <input type="text" name="nama_blok" class="form-control" value="<?= old('nama_blok') ?>" required>
        </div>
        <div class="row">
            <div class="col-md-6 mb-3">
                <label class="form-label">Luas Blok (Ha)</label>
                <input type="number" step="0.01" name="luas_blok" class="form-control" value="<?= old('luas_blok') ?>" required>
            </div>
            <div class="col-md-6 mb-3">
                <label class="form-label">Jumlah Pohon</label>
                <input type="number" name="jumlah_pohon" class="form-control" value="<?= old('jumlah_pohon') ?>" required>
            </div>
        </div>
        <div class="mb-3">
            <label class="form-label">Status Blok</label>
            <select name="status_blok" class="form-select" required>
                <option value="Aktif" <?= old('status_blok') == 'Aktif' ? 'selected' : '' ?>>Aktif</option>
                <option value="Tidak Aktif" <?= old('status_blok') == 'Tidak Aktif' ? 'selected' : '' ?>>Tidak Aktif</option>
                <option value="Replanting" <?= old('status_blok') == 'Replanting' ? 'selected' : '' ?>>Replanting</option>
            </select>
        </div>
        <button type="submit" class="btn btn-hijau">Simpan</button>
        <a href="<?= base_url('blok') ?>" class="btn btn-outline-secondary">Batal</a>
    </form>
</div>

<?= $this->include('templates/footer') ?>
