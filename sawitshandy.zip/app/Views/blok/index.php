<?= $this->include('templates/header') ?>

<div class="card card-white p-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h6 class="fw-bold m-0" style="color:#14532d">Daftar Data Blok Kebun</h6>
        <a href="<?= base_url('blok/tambah') ?>" class="btn btn-hijau btn-sm">
            <i class="bi bi-plus-lg"></i> Tambah Blok
        </a>
    </div>

    <div class="table-responsive">
        <table class="table table-hover align-middle">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Kode Blok</th>
                    <th>Nama Blok</th>
                    <th>Kebun</th>
                    <th>Luas Blok (Ha)</th>
                    <th>Jumlah Pohon</th>
                    <th>Status</th>
                    <th class="text-center">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $no = 1; ?>
                <?php foreach ($blok as $row): ?>
                <tr>
                    <td><?= $no++ ?></td>
                    <td><?= esc($row['kode_blok']) ?></td>
                    <td><?= esc($row['nama_blok']) ?></td>
                    <td><?= esc($row['nama_kebun']) ?> (<?= esc($row['kode_kebun']) ?>)</td>
                    <td><?= number_format($row['luas_blok'], 2) ?></td>
                    <td><?= esc($row['jumlah_pohon']) ?></td>
                    <td>
                        <?php
                            $cls = match ($row['status_blok']) {
                                'Aktif'       => 'badge-aktif',
                                'Replanting'  => 'badge-replanting',
                                default       => 'badge-nonaktif',
                            };
                        ?>
                        <span class="badge <?= $cls ?>"><?= esc($row['status_blok']) ?></span>
                    </td>
                    <td class="text-center">
                        <a href="<?= base_url('blok/edit/' . $row['id']) ?>" class="btn btn-sm btn-outline-success">
                            <i class="bi bi-pencil"></i>
                        </a>
                        <a href="<?= base_url('blok/hapus/' . $row['id']) ?>" class="btn btn-sm btn-outline-danger"
                           onclick="return confirm('Yakin ingin menghapus data blok ini?')">
                            <i class="bi bi-trash"></i>
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($blok)): ?>
                <tr><td colspan="8" class="text-center text-muted py-4">Belum ada data blok kebun.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?= $this->include('templates/footer') ?>
