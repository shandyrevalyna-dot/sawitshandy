<?= $this->include('templates/header') ?>

<div class="row g-3 mb-4">
    <div class="col-md-4">
        <div class="card card-stat g1 p-4">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <div style="opacity:.85">Total Kebun</div>
                    <h2 class="fw-bold mb-0"><?= esc($totalKebun) ?></h2>
                </div>
                <i class="bi bi-tree" style="font-size:2.5rem;opacity:.7"></i>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card card-stat g2 p-4">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <div style="opacity:.85">Total Luas Lahan</div>
                    <h2 class="fw-bold mb-0"><?= number_format($totalLuasLahan, 2) ?> Ha</h2>
                </div>
                <i class="bi bi-map" style="font-size:2.5rem;opacity:.7"></i>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card card-stat g3 p-4">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <div style="opacity:.85">Produksi Bulan Ini</div>
                    <h2 class="fw-bold mb-0"><?= number_format($totalProduksi, 2) ?> Kg</h2>
                </div>
                <i class="bi bi-basket" style="font-size:2.5rem;opacity:.7"></i>
            </div>
        </div>
    </div>
</div>

<div class="card card-white p-4">
    <h6 class="fw-bold mb-3" style="color:#14532d">Grafik Hasil Panen (6 Bulan Terakhir)</h6>
    <canvas id="chartPanen" height="90"></canvas>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.4/dist/chart.umd.min.js"></script>
<script>
    const ctx = document.getElementById('chartPanen');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: <?= $labelBulan ?>,
            datasets: [{
                label: 'Hasil Panen (Kg)',
                data: <?= $dataPanen ?>,
                backgroundColor: 'rgba(22, 163, 74, 0.75)',
                borderRadius: 8,
            }]
        },
        options: {
            responsive: true,
            plugins: { legend: { display: false } },
            scales: { y: { beginAtZero: true } }
        }
    });
</script>

<?= $this->include('templates/footer') ?>
