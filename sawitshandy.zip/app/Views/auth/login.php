<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | SawitShandy</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #14532d 0%, #16a34a 50%, #86efac 100%);
            font-family: 'Segoe UI', Tahoma, sans-serif;
        }
        .login-box {
            background: #ffffff;
            border-radius: 18px;
            padding: 40px 34px;
            width: 100%;
            max-width: 380px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }
        .login-box h2 { color: #14532d; font-weight: 700; }
        .login-box p.subtitle { color: #4b5563; }
        .btn-hijau {
            background: linear-gradient(135deg, #16a34a, #14532d);
            color: #fff; border: none;
        }
        .btn-hijau:hover { background: linear-gradient(135deg, #15803d, #0f3d20); color: #fff; }
    </style>
</head>
<body>
    <div class="login-box text-center">
        <h2 class="mb-1">🌴 SawitShandy</h2>
        <p class="subtitle mb-4">Sistem Informasi Perkebunan Sawit</p>

        <?php if (session()->getFlashdata('error')): ?>
            <div class="alert alert-danger py-2"><?= esc(session()->getFlashdata('error')) ?></div>
        <?php endif; ?>

        <form action="<?= base_url('login/proses') ?>" method="post" class="text-start">
            <?= csrf_field() ?>
            <div class="mb-3">
                <label class="form-label">Username</label>
                <input type="text" name="username" class="form-control" placeholder="Masukkan username" required autofocus>
            </div>
            <div class="mb-4">
                <label class="form-label">Password</label>
                <input type="password" name="password" class="form-control" placeholder="Masukkan password" required>
            </div>
            <button type="submit" class="btn btn-hijau w-100 py-2 fw-semibold">Masuk</button>
        </form>
        <p class="text-muted mt-4 mb-0" style="font-size:13px">Default: admin / admin123</p>
    </div>
</body>
</html>
