<?= $this->include('templates/header') ?>

<div class="card card-white p-4" style="max-width:640px">
    <h6 class="fw-bold mb-3" style="color:#14532d">Edit Hasil Panen</h6>

    <?php if (session('errors')): ?>
        <div class="alert alert-danger">
            <ul class="m-0">
                <?php foreach (session('errors') as $err): ?>
                    <li><?= esc($err) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?= base_url('panen/update/' . $panen['id']) ?>" method="post">
        <?= csrf_field() ?>
        <div class="mb-3">
            <label class="form-label">Kebun</label>
            <select name="kebun_id" class="form-select" required>
                <?php foreach ($listKebun as $k): ?>
                    <option value="<?= $k['id'] ?>" <?= old('kebun_id', $panen['kebun_id']) == $k['id'] ? 'selected' : '' ?>>
                        <?= esc($k['nama_kebun']) ?> (<?= esc($k['kode_kebun']) ?>)
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="mb-3">
            <label class="form-label">Blok Kebun</label>
            <select name="blok_id" class="form-select" required>
                <?php foreach ($listBlok as $b): ?>
                    <option value="<?= $b['id'] ?>" <?= old('blok_id', $panen['blok_id']) == $b['id'] ? 'selected' : '' ?>>
                        <?= esc($b['nama_blok']) ?> (<?= esc($b['kode_blok']) ?>)
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="row">
            <div class="col-md-6 mb-3">
                <label class="form-label">Jumlah Panen (Kg)</label>
                <input type="number" step="0.01" name="jumlah_panen" class="form-control" value="<?= old('jumlah_panen', $panen['jumlah_panen']) ?>" required>
            </div>
            <div class="col-md-6 mb-3">
                <label class="form-label">Tanggal Panen</label>
                <input type="date" name="tanggal_panen" class="form-control" value="<?= old('tanggal_panen', $panen['tanggal_panen']) ?>" required>
            </div>
        </div>
        <button type="submit" class="btn btn-hijau">Update</button>
        <a href="<?= base_url('panen') ?>" class="btn btn-outline-secondary">Batal</a>
    </form>
</div>

<?= $this->include('templates/footer') ?>
