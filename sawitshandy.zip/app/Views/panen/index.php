<?= $this->include('templates/header') ?>

<div class="card card-white p-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h6 class="fw-bold m-0" style="color:#14532d">Daftar Data Hasil Panen</h6>
        <a href="<?= base_url('panen/tambah') ?>" class="btn btn-hijau btn-sm">
            <i class="bi bi-plus-lg"></i> Tambah Panen
        </a>
    </div>

    <div class="table-responsive">
        <table class="table table-hover align-middle">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Kode Kebun</th>
                    <th>Kode Blok</th>
                    <th>Jumlah Panen (Kg)</th>
                    <th>Tanggal Panen</th>
                    <th class="text-center">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $no = 1; ?>
                <?php foreach ($panen as $row): ?>
                <tr>
                    <td><?= $no++ ?></td>
                    <td><?= esc($row['kode_kebun']) ?> - <?= esc($row['nama_kebun']) ?></td>
                    <td><?= esc($row['kode_blok']) ?> - <?= esc($row['nama_blok']) ?></td>
                    <td><?= number_format($row['jumlah_panen'], 2) ?></td>
                    <td><?= date('d-m-Y', strtotime($row['tanggal_panen'])) ?></td>
                    <td class="text-center">
                        <a href="<?= base_url('panen/edit/' . $row['id']) ?>" class="btn btn-sm btn-outline-success">
                            <i class="bi bi-pencil"></i>
                        </a>
                        <a href="<?= base_url('panen/hapus/' . $row['id']) ?>" class="btn btn-sm btn-outline-danger"
                           onclick="return confirm('Yakin ingin menghapus data panen ini?')">
                            <i class="bi bi-trash"></i>
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($panen)): ?>
                <tr><td colspan="6" class="text-center text-muted py-4">Belum ada data hasil panen.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?= $this->include('templates/footer') ?>
