<?= $this->include('templates/header') ?>

<div class="card card-white p-4" style="max-width:640px">
    <h6 class="fw-bold mb-3" style="color:#14532d">Edit Data Kebun</h6>

    <?php if (session('errors')): ?>
        <div class="alert alert-danger">
            <ul class="m-0">
                <?php foreach (session('errors') as $err): ?>
                    <li><?= esc($err) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?= base_url('kebun/update/' . $kebun['id']) ?>" method="post">
        <?= csrf_field() ?>
        <div class="mb-3">
            <label class="form-label">Kode Kebun</label>
            <input type="text" name="kode_kebun" class="form-control" value="<?= old('kode_kebun', $kebun['kode_kebun']) ?>" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Nama Kebun</label>
            <input type="text" name="nama_kebun" class="form-control" value="<?= old('nama_kebun', $kebun['nama_kebun']) ?>" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Lokasi</label>
            <input type="text" name="lokasi" class="form-control" value="<?= old('lokasi', $kebun['lokasi']) ?>" required>
        </div>
        <div class="row">
            <div class="col-md-6 mb-3">
                <label class="form-label">Luas Lahan (Ha)</label>
                <input type="number" step="0.01" name="luas_lahan" class="form-control" value="<?= old('luas_lahan', $kebun['luas_lahan']) ?>" required>
            </div>
            <div class="col-md-6 mb-3">
                <label class="form-label">Tahun Tanam</label>
                <input type="number" name="tahun_tanam" class="form-control" value="<?= old('tahun_tanam', $kebun['tahun_tanam']) ?>" required>
            </div>
        </div>
        <div class="mb-3">
            <label class="form-label">Keterangan</label>
            <textarea name="keterangan" class="form-control" rows="3"><?= old('keterangan', $kebun['keterangan']) ?></textarea>
        </div>
        <button type="submit" class="btn btn-hijau">Update</button>
        <a href="<?= base_url('kebun') ?>" class="btn btn-outline-secondary">Batal</a>
    </form>
</div>

<?= $this->include('templates/footer') ?>
