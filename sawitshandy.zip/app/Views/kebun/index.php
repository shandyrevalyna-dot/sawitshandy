<?= $this->include('templates/header') ?>

<div class="card card-white p-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h6 class="fw-bold m-0" style="color:#14532d">Daftar Data Kebun</h6>
        <a href="<?= base_url('kebun/tambah') ?>" class="btn btn-hijau btn-sm">
            <i class="bi bi-plus-lg"></i> Tambah Kebun
        </a>
    </div>

    <div class="table-responsive">
        <table class="table table-hover align-middle">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Kode Kebun</th>
                    <th>Nama Kebun</th>
                    <th>Lokasi</th>
                    <th>Luas Lahan (Ha)</th>
                    <th>Tahun Tanam</th>
                    <th>Keterangan</th>
                    <th class="text-center">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $no = 1; ?>
                <?php foreach ($kebun as $row): ?>
                <tr>
                    <td><?= $no++ ?></td>
                    <td><?= esc($row['kode_kebun']) ?></td>
                    <td><?= esc($row['nama_kebun']) ?></td>
                    <td><?= esc($row['lokasi']) ?></td>
                    <td><?= number_format($row['luas_lahan'], 2) ?></td>
                    <td><?= esc($row['tahun_tanam']) ?></td>
                    <td><?= esc($row['keterangan']) ?></td>
                    <td class="text-center">
                        <a href="<?= base_url('kebun/edit/' . $row['id']) ?>" class="btn btn-sm btn-outline-success">
                            <i class="bi bi-pencil"></i>
                        </a>
                        <a href="<?= base_url('kebun/hapus/' . $row['id']) ?>" class="btn btn-sm btn-outline-danger"
                           onclick="return confirm('Yakin ingin menghapus data kebun ini?')">
                            <i class="bi bi-trash"></i>
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($kebun)): ?>
                <tr><td colspan="8" class="text-center text-muted py-4">Belum ada data kebun.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?= $this->include('templates/footer') ?>
