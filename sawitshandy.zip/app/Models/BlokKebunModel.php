<?php

namespace App\Models;

use CodeIgniter\Model;

class BlokKebunModel extends Model
{
    protected $table            = 'blok_kebun';
    protected $primaryKey       = 'id';
    protected $allowedFields    = [
        'kebun_id', 'kode_blok', 'nama_blok', 'luas_blok', 'jumlah_pohon', 'status_blok',
    ];
    protected $useTimestamps    = true;
    protected $createdField     = 'created_at';
    protected $updatedField     = 'updated_at';

    protected $validationRules = [
        'kebun_id'     => 'required',
        'kode_blok'    => 'required|is_unique[blok_kebun.kode_blok,id,{id}]',
        'nama_blok'    => 'required',
        'luas_blok'    => 'required|decimal',
        'jumlah_pohon' => 'required|numeric',
        'status_blok'  => 'required',
    ];

    // Join dengan tabel kebun agar nama kebun ikut tampil
    public function getBlokWithKebun($id = null)
    {
        $builder = $this->select('blok_kebun.*, kebun.nama_kebun, kebun.kode_kebun')
                         ->join('kebun', 'kebun.id = blok_kebun.kebun_id');

        if ($id !== null) {
            return $builder->where('blok_kebun.id', $id)->first();
        }

        return $builder->orderBy('blok_kebun.id', 'DESC')->findAll();
    }
}
