<?php

namespace App\Models;

use CodeIgniter\Model;

class HasilPanenModel extends Model
{
    protected $table            = 'hasil_panen';
    protected $primaryKey       = 'id';
    protected $allowedFields    = [
        'kebun_id', 'blok_id', 'jumlah_panen', 'tanggal_panen',
    ];
    protected $useTimestamps    = true;
    protected $createdField     = 'created_at';
    protected $updatedField     = 'updated_at';

    protected $validationRules = [
        'kebun_id'      => 'required',
        'blok_id'       => 'required',
        'jumlah_panen'  => 'required|decimal',
        'tanggal_panen' => 'required|valid_date',
    ];

    // Join agar nama kebun & blok ikut tampil di tabel data hasil panen
    public function getPanenWithRelasi($id = null)
    {
        $builder = $this->select('hasil_panen.*, kebun.nama_kebun, kebun.kode_kebun, blok_kebun.nama_blok, blok_kebun.kode_blok')
                         ->join('kebun', 'kebun.id = hasil_panen.kebun_id')
                         ->join('blok_kebun', 'blok_kebun.id = hasil_panen.blok_id');

        if ($id !== null) {
            return $builder->where('hasil_panen.id', $id)->first();
        }

        return $builder->orderBy('hasil_panen.tanggal_panen', 'DESC')->findAll();
    }

    // Total produksi bulan berjalan (untuk kartu dashboard)
    public function totalProduksiBulanIni()
    {
        $bulan = date('m');
        $tahun = date('Y');

        return $this->selectSum('jumlah_panen')
                     ->where('MONTH(tanggal_panen)', $bulan)
                     ->where('YEAR(tanggal_panen)', $tahun)
                     ->first()['jumlah_panen'] ?? 0;
    }

    // Rekap panen per bulan (6 bulan terakhir) untuk grafik dashboard
    public function rekapPanenPerBulan()
    {
        return $this->select("DATE_FORMAT(tanggal_panen, '%Y-%m') as bulan, SUM(jumlah_panen) as total")
                     ->where('tanggal_panen >=', date('Y-m-d', strtotime('-5 months', strtotime(date('Y-m-01')))))
                     ->groupBy('bulan')
                     ->orderBy('bulan', 'ASC')
                     ->findAll();
    }
}
