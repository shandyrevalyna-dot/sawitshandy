<?php

namespace App\Models;

use CodeIgniter\Model;

class KebunModel extends Model
{
    protected $table            = 'kebun';
    protected $primaryKey       = 'id';
    protected $allowedFields    = [
        'kode_kebun', 'nama_kebun', 'lokasi', 'luas_lahan', 'tahun_tanam', 'keterangan',
    ];
    protected $useTimestamps    = true;
    protected $createdField     = 'created_at';
    protected $updatedField     = 'updated_at';

    protected $validationRules = [
        'kode_kebun'  => 'required|is_unique[kebun.kode_kebun,id,{id}]',
        'nama_kebun'  => 'required|min_length[3]',
        'lokasi'      => 'required',
        'luas_lahan'  => 'required|decimal',
        'tahun_tanam' => 'required|numeric',
    ];

    protected $validationMessages = [
        'kode_kebun' => [
            'is_unique' => 'Kode kebun sudah digunakan, gunakan kode lain.',
        ],
    ];

    // Total luas lahan seluruh kebun
    public function totalLuasLahan()
    {
        return $this->selectSum('luas_lahan')->first()['luas_lahan'] ?? 0;
    }
}
